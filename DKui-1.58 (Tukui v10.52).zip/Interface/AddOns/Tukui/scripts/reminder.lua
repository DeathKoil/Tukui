if TukuiDB["buffreminder"].enable ~= true then return end

-- Spells that should be shown with an icon in the middle of the screen when not buffed in combat.
-- Use the rank 1 id for best results. The first valid spell in each class's list will be the icon shown. 
TukuiDB["buffreminder"].buffs = {
	PRIEST = {
		588, -- inner fire
		-- 1243, -- PWF testing. (Learned at lvl 1)
	},
	HUNTER = {
		13163, -- monkey
		13165, -- hawk
		5118, -- cheetah
		34074, -- viper
		13161, -- beast
		13159, -- pack
		20043, -- wild
		61846, -- dragonhawk
	},
	MAGE = {
		168, -- frost armor
		6117, -- mage armor
		7302, -- ice armor
		30482, -- molten armor
	},
	WARLOCK = {
		28176, -- fel armor
		706, -- demon armor
		687, -- demon skin
	},
	PALADIN = {
		21084, -- seal of righteousness
		20375, -- seal of command
		20164, -- seal of justice
		20165, -- seal of light
		20166, -- seal of wisdom
		53736, -- seal of corruption
		31801, -- seal of vengeance
	},
	SHAMAN = {
		52127, -- water shield
		324, -- lightning shield
		974, -- earth shield
	},
	WARRIOR = {
		469, -- commanding Shout
		6673, -- battle Shout
	},
	DEATHKNIGHT = {
		57330, -- horn of Winter
		8075, -- Shaman Strength of Earth Totem
	},
}

-- Nasty stuff below. Don't touch.
local class = select(2, UnitClass("Player"))
local buffs = TukuiDB["buffreminder"].buffs[class]

if (buffs and buffs[1]) then
	local function OnEvent(self, event)
		if (event == "PLAYER_LOGIN" or event == "LEARNED_SPELL_IN_TAB") then
			for i, buff in pairs(buffs) do
				local name = GetSpellInfo(buff)
				local usable, nomana = IsUsableSpell(name)
				if (usable or nomana) then
					self.icon:SetTexture(select(3, GetSpellInfo(buff)))
					break
				end
			end
			if (not self.icon:GetTexture() and event == "PLAYER_LOGIN") then
				self:UnregisterAllEvents()
				self:RegisterEvent("LEARNED_SPELL_IN_TAB")
				return
			elseif (self.icon:GetTexture() and event == "LEARNED_SPELL_IN_TAB") then
				self:UnregisterAllEvents()
				self:RegisterEvent("UNIT_AURA")
				self:RegisterEvent("PLAYER_LOGIN")
				self:RegisterEvent("PLAYER_REGEN_ENABLED")
				self:RegisterEvent("PLAYER_REGEN_DISABLED")
			end
		end
		if (UnitAffectingCombat("player") and not UnitInVehicle("player")) then
			for i, buff in pairs(buffs) do
				local name = GetSpellInfo(buff)
				if (name and UnitBuff("player", name)) then
					self:Hide()
					return
				end
			end
			self:Show()
			if TukuiDB["buffreminder"].sound == true then
				PlaySoundFile(TukuiDB["media"].warning)
			end
		else
			self:Hide()
		end
	end
	
	local frame = CreateFrame("Frame", _, UIParent)
	TukuiDB:CreatePanel(frame, TukuiDB:Scale(40), TukuiDB:Scale(40), "CENTER", UIParent, "CENTER", 0, TukuiDB:Scale(200))
	
	frame.icon = frame:CreateTexture(nil, "OVERLAY")
	frame.icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
	frame.icon:SetPoint("CENTER")
	frame.icon:SetWidth(TukuiDB:Scale(36))
	frame.icon:SetHeight(TukuiDB:Scale(36))
	frame:Hide()
	
	frame:RegisterEvent("UNIT_AURA")
	frame:RegisterEvent("PLAYER_LOGIN")
	frame:RegisterEvent("PLAYER_REGEN_ENABLED")
	frame:RegisterEvent("PLAYER_REGEN_DISABLED")
	
	frame:SetScript("OnEvent", OnEvent)
end